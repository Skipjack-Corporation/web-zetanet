self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4beb78a1ea08a7a3482a77ad450a90a6",
    "url": "/index.html"
  },
  {
    "revision": "374104b967707e5e8387",
    "url": "/static/css/2.ac169b45.chunk.css"
  },
  {
    "revision": "46e9b39934e187194624",
    "url": "/static/css/main.a976d9e7.chunk.css"
  },
  {
    "revision": "374104b967707e5e8387",
    "url": "/static/js/2.987ea752.chunk.js"
  },
  {
    "revision": "46e9b39934e187194624",
    "url": "/static/js/main.22889ee7.chunk.js"
  },
  {
    "revision": "e90ac9c546aeb26a4bd0",
    "url": "/static/js/runtime~main.f949f7e3.js"
  },
  {
    "revision": "85d339d916479f729938d2911b85bf1f",
    "url": "/static/media/Lato-Bold.85d339d9.ttf"
  },
  {
    "revision": "2fe27d9d10cdfccb1baef28a45d5ba90",
    "url": "/static/media/Lato-Light.2fe27d9d.ttf"
  },
  {
    "revision": "2d36b1a925432bae7f3c53a340868c6e",
    "url": "/static/media/Lato-Regular.2d36b1a9.ttf"
  },
  {
    "revision": "f49f3d2d9df5013c9bfaab7e3d39ee57",
    "url": "/static/media/Raleway-Bold.f49f3d2d.ttf"
  },
  {
    "revision": "466d154fedd98f85c9deb363ccf859a7",
    "url": "/static/media/Raleway-Light.466d154f.ttf"
  },
  {
    "revision": "9942588a6c84f959132556d99e83ded6",
    "url": "/static/media/Raleway-Regular.9942588a.ttf"
  },
  {
    "revision": "aa9105d27e6fe8e6d435471ab15f1199",
    "url": "/static/media/Z-tech.aa9105d2.gif"
  },
  {
    "revision": "c455ec93e9cc618ef18349f77cfa19c0",
    "url": "/static/media/adam-cg-pro.regular.c455ec93.otf"
  },
  {
    "revision": "348888acc55cbb3a1653ae2ea90eafe8",
    "url": "/static/media/arrow-left.348888ac.png"
  },
  {
    "revision": "22544b058f2e9f19de52001c41bc2d4e",
    "url": "/static/media/arrow-right.22544b05.png"
  },
  {
    "revision": "e8c2b1df979fa2de4b3ca10c51c83dff",
    "url": "/static/media/arrow.e8c2b1df.svg"
  },
  {
    "revision": "f65e8dc71de2787dc74a20d06d9a66a5",
    "url": "/static/media/circuit.f65e8dc7.png"
  },
  {
    "revision": "ec31a207e77846c0b0e93140e8379543",
    "url": "/static/media/close.ec31a207.svg"
  },
  {
    "revision": "0172a80e2c729256a4e3b9b1220f8800",
    "url": "/static/media/icons-arrow.0172a80e.svg"
  },
  {
    "revision": "e1df5749a9b4dd6c0b6e59c2897ea5cf",
    "url": "/static/media/press.e1df5749.png"
  },
  {
    "revision": "28d3972fd439f67ab877dc8eec8c2fb9",
    "url": "/static/media/quantum-brain-img.28d3972f.png"
  },
  {
    "revision": "c5fd28f24591a5fa6ba2fca368f75991",
    "url": "/static/media/quantum-comp.c5fd28f2.png"
  },
  {
    "revision": "f63e3b9a6a15fcf0263d8127be85fd6e",
    "url": "/static/media/roadmap-img.f63e3b9a.png"
  },
  {
    "revision": "74e91997071d2c7907b8cb6829f394f1",
    "url": "/static/media/roadmap_img.74e91997.png"
  },
  {
    "revision": "7c9fa6792a46f5dc105040847a810307",
    "url": "/static/media/team_bg.7c9fa679.png"
  },
  {
    "revision": "2130fdc77c021975876b7a0ddc25cdf5",
    "url": "/static/media/tech_banner.2130fdc7.png"
  },
  {
    "revision": "0417aadbb1d195950d959e60a0c711dc",
    "url": "/static/media/technology.0417aadb.png"
  },
  {
    "revision": "968d1c9176b6b7c9cc704a8091143cc2",
    "url": "/static/media/world_connect.968d1c91.png"
  }
]);